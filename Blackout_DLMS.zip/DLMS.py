import serial
import binascii
import time
import make_CRC

header = '7E A0'
footer = '7E'

def strTolist(string):
    list1 = string.split(' ')
    for i in range(len(list1)):
        list1[i] = int(list1[i], 16)
    return list1

def SNRMquery(dst, src):
    frame = '93'
    client = hex((int(src) + 16)*2+1)[-2:]
    server = hex((int(dst) + 16)*2+1)[-2:]

    if (int(src) + 16)*2+1 > 111:
        client = '08 02 ' + hex((int(src) + 16)*2+1)[-2:]

    if (int(dst) + 16)*2+1 > 111:
        server = '08 02 ' + hex((int(dst) + 16)*2+1)[-2:]

    CRC = make_CRC.crc16(strTolist(header[-2:] + " " + server + " " + client + " " + frame))

    packet = header + " " + server + " " + client + " " + frame + " " + CRC + " " + footer

    return packet

def AARQquery(dst, src):
    snrm_header = SNRMquery(dst, src)[:-2]
    aarq_header = 'e6 e6 00'


def connect(serialport): # dst, src
    with serial.Serial(serialport, 9600, timeout=1) as sr:
        # SNRM
        #arr1 = SNRMquery(dst,src)
        arr1 = '7E A0 08 02 FF 23 93 A1 7D 7E'
        # AARQ
        arr2 = '7E A0 45 02 FF 23 10 64 76 E6 E6 00 60 36 A1 09 06 07 60 85 74 05 08 01 01 8A 02 07 80 8B 07 60 85 74 05 08 02 01 AC 0A 80 08 31 31 31 31 31 31 31 31 BE 10 04 0E 01 00 00 00 06 5F 1F 04 00 00 18 1D FF FF 4e 7f 7E'
        # set
        #arr3 = '7E A0 24 02 FF 23 54 B3 D8 E6 E6 00 C1 01 81 00 08 00 00 01 00 00 FF 02 00 09 08 07 E2 04 0C 04 0A 22 39 24 d6 7E'
        #get

        arr4 = '7E A0 1A 02 FF 23 32 EA 6B E6 E6 00 C0 01 81 00 0f 00 00 28 00 00 FF 07 00 2c e0 7E'
        #arr4 = '7e a0 24 02 FF 23 32 83 de e6 e6 00 c1 01 81 00 0f 00 00 28 00 00 ff 07 00 09 08 31 31 31 31 31 31 31 31 75 4a 7e'
        arr5 = '7E A0 08 02 FF 23 53 AD BB 7E'

        arr1 = strTolist(arr1)
        arr2 = strTolist(arr2)
        #arr3 = strTolist(arr3)
        arr4 = strTolist(arr4)
        arr5 = strTolist(arr5)
        #arr6 = strTolist(arr6)
        #arr7 = strTolist(arr7)

        sr.write(serial.to_bytes(arr1))
        print("UA Request \n==>")
        result = sr.readall()
        result = binascii.hexlify(result).decode()
        print(result)
        print(len(result) / 2)
        time.sleep(1)


        sr.write(serial.to_bytes(arr2))
        result = sr.readall()
        result = binascii.hexlify(result).decode()
        print(result)
        print(len(result) / 2)
        time.sleep(1)

        '''sr.write(serial.to_bytes(arr3))
        result = sr.readall()
        result = binascii.hexlify(result).decode()
        print(result)
        print(len(result) / 2)
        time.sleep(1)
'''
        sr.write(serial.to_bytes(arr4))
        result = sr.readall()
        result = binascii.hexlify(result).decode()
        print(result)
        print(len(result) / 2)
        time.sleep(1)

        sr.write(serial.to_bytes(arr5))
        result = sr.readall()
        result = binascii.hexlify(result).decode()
        print(result)
        print(len(result) / 2)
        time.sleep(1)
'''
        sr.write(serial.to_bytes(arr6))
        result = sr.readall()
        result = binascii.hexlify(result).decode()
        print(result)
        print(len(result) / 2)
        time.sleep(1)

        sr.write(serial.to_bytes(arr7))
        result = sr.readall()
        result = binascii.hexlify(result).decode()
        print(result)
        print(len(result) / 2)
        time.sleep(1)
'''
#def ua_structure():
AARQquery(111, 1)

